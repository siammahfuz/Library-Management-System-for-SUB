<?php 
session_start();
include('includes/config.php');
error_reporting(0);

if(strlen($_SESSION['login']) == 0) {
    header('location:index.php');
    exit;
}

if(isset($_POST['change'])) {
    $sid = $_SESSION['stdid'];
    $oldPassword = $_POST['old-password'] ?? '';
    $newPassword = $_POST['new-password'] ?? '';
    $confirmPassword = $_POST['confirm-password'] ?? '';

    if(empty($oldPassword) || empty($newPassword) || empty($confirmPassword)) {
        echo "<script>alert('All fields are required.');</script>";
    } elseif($newPassword !== $confirmPassword) {
        echo "<script>alert('New password and confirm password do not match.');</script>";
    } else {
        // Fetch old password
        $sql = "SELECT Password FROM tblstudents WHERE StudentId = :sid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':sid', $sid, PDO::PARAM_STR);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result) {
            if(md5($oldPassword) !== $result['Password']) {
                echo "<script>alert('Old password is incorrect.');</script>";
            } else {
                // Update new password
                $newHashed = md5($newPassword);
                $updateSql = "UPDATE tblstudents SET Password = :newpass, UpdationDate = NOW() WHERE StudentId = :sid";
                $updateQuery = $dbh->prepare($updateSql);
                $updateQuery->bindParam(':newpass', $newHashed, PDO::PARAM_STR);
                $updateQuery->bindParam(':sid', $sid, PDO::PARAM_STR);
                if($updateQuery->execute()) {
                    echo "<script>alert('Password changed successfully.');</script>";
                } else {
                    echo "<script>alert('Failed to update password.');</script>";
                }
            }
        } else {
            echo "<script>alert('Student not found.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="container">
    <h3>Change Password</h3>
    <form method="POST">
        <div class="form-group">
            <label for="old-password">Old Password</label>
            <input class="form-control" type="password" name="old-password" required>
        </div>
        <div class="form-group">
            <label for="new-password">New Password</label>
            <input class="form-control" type="password" name="new-password" required>
        </div>
        <div class="form-group">
            <label for="confirm-password">Confirm New Password</label>
            <input class="form-control" type="password" name="confirm-password" required>
        </div>
        <button type="submit" name="change" class="btn btn-success">Update Password</button>
    </form>
    <br><hr>
    <button type="submit" class="btn btn-info"><a href="http://localhost/library/dashboard.php" class="herf">Back Here</a></button>
</div>
<br><br>
<?php include('includes/footer.php'); ?>
</body>
</html>
