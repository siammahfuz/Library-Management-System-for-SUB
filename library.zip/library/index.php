<?php
session_start();
error_reporting(0);
include('includes/config.php');

$showImages = true; // Flag to control whether to show images or not

// If user is logged in, hide images
if($_SESSION['login'] != ''){
    $_SESSION['login'] = '';
    $showImages = false; // Set flag to false to hide images
}

if(isset($_POST['login'])) {
    $email = $_POST['emailid'];
    $password = md5($_POST['password']);
    $sql = "SELECT EmailId, Password, StudentId, Status FROM tblstudents WHERE EmailId=:email and Password=:password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);

    if($query->rowCount() > 0) {
        foreach ($results as $result) {
            $_SESSION['stdid'] = $result->StudentId;
            if($result->Status == 1) {
                $_SESSION['login'] = $_POST['emailid'];
                echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
            } else {
                echo "<script>alert('Your Account Has been blocked. Please contact admin');</script>";
            }
        }
    } else {
        echo "<script>alert('Invalid Details');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SUB Library Management System</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #333;
            overflow: hidden;
            padding: 10px 0;
        }
        nav a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        nav a:hover {
            background-color: #ddd;
            color: black;
        }
        nav .login-btn {
            float: right;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
        }
        .header-image img, .event-image img {
            width: 100%;
            height: auto;
        }
        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 1px;
            background-color: #6a5acd;
            color: white;
            text-align: center;
            padding: 10px;
        }
        .calendar div {
            padding: 20px 0;
            background-color: #7b68ee;
        }
        .comments {
            padding: 20px;
            background-color: #f9f9f9;
            text-align: center;
        }
        .comment-box {
            background-color: white;
            border: 1px solid #ddd;
            margin: 10px auto;
            padding: 15px;
            width: 80%;
        }
        footer {
            background-color: #2e8b57;
            color: white;
            padding: 20px;
            text-align: center;
        }
        footer .contact-info, footer .address, footer .useful-links {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php');?>

    <!-- Display header image only if $showImages is true -->
    <?php if($showImages): ?>
        <div class="header-image">
            <img src="assets/img/1.jpg" alt="University Event">
        </div>
    <?php endif; ?>

    <!-- Display event image only if $showImages is true -->
    <?php if($showImages): ?>
        <div class="event-image">
            <img src="assets/img/2.jpg" alt="Event Highlight">
        </div>
    <?php endif; ?>

    

    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">USER LOGIN FORM</h4>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <div class="panel panel-info">
                    <div class="panel-heading">LOGIN FORM</div>
                    <div class="panel-body">
                        <form role="form" method="post">
                            <div class="form-group">
                                <label>Enter Email id</label>
                                <input class="form-control" type="text" name="emailid" required autocomplete="off" />
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="password" name="password" required autocomplete="off" />
                                <p class="help-block"><a href="user-forgot-password.php">Forgot Password</a></p>
                            </div>
                            <button type="submit" name="login" class="btn btn-info">LOGIN</button> | <a href="signup.php">Not Registered Yet</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer style="background-color: green; color: white; padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; flex-wrap: wrap; max-width: 1200px; margin: 0 auto; padding: 0 20px;">

        <!-- Social Media Icons -->
        <div style="flex: 1; min-width: 200px;">
    <h3>Follow Us:</h3>
            <div style="display: flex; gap: 15px;">
                <a href="https://www.facebook.com/subedubd" target="_blank" rel="noopener noreferrer">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook" style="width: 30px; height: 30px;"/>
                </a>
                <a href="https://www.instagram.com/state_university_of_bangladesh/" target="_blank" rel="noopener noreferrer">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/9/95/Instagram_logo_2022.svg" alt="Instagram" style="width: 30px; height: 30px;"/>
                </a>
                <a href="https://www.linkedin.com/school/state-university-of-bangladesh/posts/?feedView=all" target="_blank" rel="noopener noreferrer">
                    <img src="https://static.vecteezy.com/system/resources/previews/018/930/480/non_2x/linkedin-logo-linkedin-icon-transparent-free-png.png" alt="LinkedIn" style="width: 30px; height: 30px;"/>
                </a>
                <a href="https://www.youtube.com/@sub_edu_bd" target="_blank" rel="noopener noreferrer">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/4/42/YouTube_icon_%282013-2017%29.png" alt="YouTube" style="width: 30px; height: 30px;"/>
                </a>
            </div>
        </div>

        <!-- Contact Info -->
        <div class="contact-info" style="flex: 1; min-width: 250px;">
            <h3>Contact:</h3>
            <p><strong>LANDPHONE:</strong></p>
            <p>+880258151782-4</p>
            <p>09606782338</p>
            <p><strong>Phone:</strong> +880123456789</p>
            <br>
            <p><strong>HOTLINE:</strong></p>
            <p>16665, 0176662120</p>
            <p>01766661555</p>
            <p>01766663557</p>
            <p>01766663558</p>
            <br>
            <p><strong>Email:</strong></p>
            <p>info@sub.edu.bd</p>
        </div>

        <!-- Address -->
        <div class="address" style="flex: 1; min-width: 250px;">
            <h3>Address</h3>
            <p>696 Kendua, Kanchan,<br> Rupganj, Narayanganj,<br> Dhaka-1461, Bangladesh</p>
        </div>

        <!-- Useful Links -->
        <div class="useful-links" style="flex: 1; min-width: 250px;">
            <h3>Useful Links</h3>
            <a href="https://www.sub.ac.bd/" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">SUB Official Website</a>
            <a href="https://www.sub.ac.bd/international-affairs" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">International Affairs</a>
            <a href="https://www.sub.ac.bd/contact" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">Contact</a>
            <a href="https://www.sub.ac.bd/department/computer-science-and-engineering" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">Service</a>
            <a href="https://www.facebook.com/subedubd" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">SUB Official FB Page</a>
            <a href="https://www.facebook.com/CSESUB" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">CSE Dept FB Page</a>
            <a href="https://www.sub.ac.bd/department/computer-science-and-engineering" target="_blank" rel="noopener noreferrer" style="color:white; display:block; margin-bottom: 5px;">Resource Library</a>
        </div>

    </div>
</footer>


    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/custom.js"></script>
</body>
</html>
