<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "library";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST["name"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $current_password = $_POST["current_password"];
    $new_password = $_POST["new_password"];
    $confirm_password = $_POST["confirm_password"];

    $user_id = $_SESSION["users2_id"];
    
    // Fetch the current password
    $sql = "SELECT password FROM users2 WHERE id='$user_id'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (!empty($current_password)) {
            // Verify old password
            if (password_verify($current_password, $row["password"])) {
                if ($new_password == $confirm_password) {
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                    $update_sql = "UPDATE users2 SET name='$name', email='$email', password='$hashed_password' WHERE id='$user_id'";
                    if ($conn->query($update_sql)) {
                        echo "Profile updated and password changed successfully!";
                    } else {
                        echo "Error updating record: " . $conn->error;
                    }
                } else {
                    echo "New passwords do not match!";
                }
            } else {
                echo "Current password is incorrect!";
            }
        } else {
            // If no password change, just update name & email
            $update_sql = "UPDATE users2 SET name='$name', email='$email' WHERE id='$user_id'";
            if ($conn->query($update_sql)) {
                echo "Profile updated successfully!";
            } else {
                echo "Error updating record: " . $conn->error;
            }
        }
    } else {
        echo "User not found!";
    }
}

$conn->close();
?>
