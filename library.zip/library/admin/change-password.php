<?php
session_start();
include('includes/config.php');
error_reporting(0);

if(strlen($_SESSION['alogin']) == 0) {   
    header('location:index.php');
    exit();
} else { 
    if(isset($_POST['change'])) {
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];
        $confirmpassword = $_POST['confirmpassword'];
        $username = $_SESSION['alogin'];

        // Password Matching Check
        if ($newpassword !== $confirmpassword) {
            $error = "New Password and Confirm Password do not match!";
        } else {
            // Fetch Current Password
            $sql = "SELECT Password FROM admin WHERE UserName = :username";
            $query = $dbh->prepare($sql);
            $query->bindParam(':username', $username, PDO::PARAM_STR);
            $query->execute();
            $result = $query->fetch(PDO::FETCH_OBJ);

            if ($result && password_verify($password, $result->Password)) {
                // Hash New Password Securely
                $newpasswordHash = password_hash($newpassword, PASSWORD_DEFAULT);

                // Update Password
                $sql = "UPDATE admin SET Password = :newpassword WHERE UserName = :username";
                $chngpwd = $dbh->prepare($sql);
                $chngpwd->bindParam(':username', $username, PDO::PARAM_STR);
                $chngpwd->bindParam(':newpassword', $newpasswordHash, PDO::PARAM_STR);
                $chngpwd->execute();

                $msg = "Your Password has been successfully changed.";
            } else {
                $error = "Your current password is incorrect!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Change Password | Online Library</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <script type="text/javascript">
        function valid() {
            if (document.chngpwd.newpassword.value != document.chngpwd.confirmpassword.value) {
                alert("New Password and Confirm Password do not match!");
                document.chngpwd.confirmpassword.focus();
                return false;
            }
            return true;
        }
    </script>
</head>
<body>

<?php include('includes/header.php');?>

<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">User Change Password</h4>
            </div>
        </div>

        <?php if(isset($error)) { ?>
            <div class="alert alert-danger"><strong>ERROR:</strong> <?php echo htmlentities($error); ?> </div>
        <?php } else if(isset($msg)) { ?>
            <div class="alert alert-success"><strong>SUCCESS:</strong> <?php echo htmlentities($msg); ?> </div>
        <?php } ?>            

        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-info">
                    <div class="panel-heading">Change Password</div>
                    <div class="panel-body">
                        <form role="form" method="post" onSubmit="return valid();" name="chngpwd">
                            <div class="form-group">
                                <label>Current Password</label>
                                <input class="form-control" type="password" name="password" required />
                            </div>

                            <div class="form-group">
                                <label>New Password</label>
                                <input class="form-control" type="password" name="newpassword" required />
                            </div>

                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input class="form-control" type="password" name="confirmpassword" required />
                            </div>

                            <button type="submit" name="change" class="btn btn-info">Change</button> 
                        </form>
                    </div>
                </div>
            </div>
        </div>  
    </div>
</div>

<?php include('includes/footer.php');?>

<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/custom.js"></script>

</body>
</html>