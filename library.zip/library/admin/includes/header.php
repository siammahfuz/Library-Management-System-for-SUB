<?php
session_start();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<div class="navbar navbar-inverse set-radius-zero" >
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand">
                <img src="assets/img/logo.png" />
            </a>
        </div>
        <div class="right-div">
            <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
        </div>
    </div>
</div>

<!-- MENU SECTION START-->
<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse ">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">

                        <li><a href="dashboard.php" <?php if($currentPage == 'dashboard.php') echo 'class="menu-top-active"'; ?>>DASHBOARD</a></li>

                        <?php if($currentPage != 'my-profile.php') { ?>
                        <li><a href="issued-books.php" <?php if($currentPage == 'issued-books.php') echo 'class="menu-top-active"'; ?>>Issued Books</a></li>
                        <li><a href="my-profile.php" <?php if($currentPage == 'my-profile.php') echo 'class="menu-top-active"'; ?>>Profile</a></li>
                        <?php } ?>

                        <li><a href="change-password.php" <?php if($currentPage == 'change-password.php') echo 'class="menu-top-active"'; ?>>Change Password</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- MENU SECTION END-->
