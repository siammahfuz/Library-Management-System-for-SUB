<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:index.php');
}
else{?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            height: 100vh;
            padding: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px 0;
            text-decoration: none;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .main-content {
            flex: 1;
            padding: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th, .table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .table th {
            background-color: #f2f2f2;
        }

        .button {
            padding: 8px 12px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <a href="?page=profile">My Profile</a>
        <a href="?page=manage_books">Manage Book</a>
        <a href="?page=search_books">Search Book</a>
        <a href="?page=manage_users">Manage User</a>
        <a href="?page=issue_book">Issue Book</a>
        <a href="?page=return_book">Return Book</a>
        <a href="?page=show_report">Show Report</a>
        <a href="?page=notify_users">Notify User</a>
        <a href="?page=password">Password</a>
        <a href="?page=settings">Settings</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main-content">
        <?php
        $page = $_GET['page'] ?? 'manage_books';

        // My Profile Section
        if ($page === 'profile') {
            echo "<h2>My Profile</h2>";
                echo "<form action='update_profile.php' method='post'>";
            
                echo "<label><strong>Name:</strong></label>";
                echo "<input type='text' name='name' value='admin' required><br><br>";
                
                echo "<label><strong>Change Password:</strong></label>";
                echo "<input type='password' name='password' value='admin' required><br><br>";
                 
               
               

// Back Button
echo "<a href='index.php' style='display: inline-block; padding: 10px 15px; background-color: #007bff; color: #fff; text-decoration: none; border-radius: 5px;'>Back</a>";

            
                echo "</form>";}
                
                
                
                
                
                
                
                
                
                
                // Manage Books Section 
                if ($page === 'manage_books') {
                    echo '<h2>Manage Books</h2>';
                    
                   // Add Book Button - Redirects to Add Book Page
echo '<button style="background-color: blue; color: white; padding: 10px 20px; border: none; cursor: pointer; border-radius: 5px; margin-bottom: 15px;" onclick="window.location.href=\'?page=add_book\'">Add Book</button>';
// Search Form
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

echo '<form method="GET">
        <input type="hidden" name="page" value="manage_books">
        <input type="text" name="search" placeholder="Search by title, author, category..." value="' . htmlspecialchars($search_query, ENT_QUOTES) . '" required>
        <button type="submit">Search</button>
      </form>';

// SQL Query with Search Filter (Using Prepared Statement)
$sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ?";
$stmt = $conn->prepare($sql);
$search_param = "%" . $search_query . "%";
$stmt->bind_param("sss", $search_param, $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();

// Display Books Table
echo '<table class="table">
        <tr>
            <th>Access Number</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Available</th>
            <th>Actions</th>
        </tr>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>' . htmlspecialchars($row['access_number']) . '</td>
                <td>' . htmlspecialchars($row['title']) . '</td>
                <td>' . htmlspecialchars($row['author']) . '</td>
                <td>' . htmlspecialchars($row['category']) . '</td>
                <td>' . ($row['available'] ? 'Yes' : 'No') . '</td>
                <td>
                    <a href="?page=edit_book&id=' . $row['id'] . '" class="button">Edit</a>
                    <a href="?page=delete_book&id=' . $row['id'] . '" class="button" style="background-color: red; color: white;" onclick="return confirm(\'Are you sure?\');">Delete</a>
                </td>
              </tr>';
    }
} else {
    echo '<tr><td colspan="6" style="text-align:center; color:red;">No books found.</td></tr>';
}

echo '</table>';
$stmt->close();
}
// Add Book Page
if ($page === 'add_book') {
    echo '<h2>Add Book</h2>';
    echo '<form method="POST" action="">
            <label for="access_number">Access Number:</label><br>
            <input type="text" id="access_number" name="access_number" required><br>

            <label for="title">Title:</label><br>
            <input type="text" id="title" name="title" required><br>

            <label for="author">Author:</label><br>
            <input type="text" id="author" name="author" required><br>

            <label for="category">Category:</label><br>
            <input type="text" id="category" name="category" required><br>

            <label for="available">Available:</label><br>
            <select id="available" name="available">
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select><br>

            <label for="details">Details:</label><br>
            <textarea id="details" name="details"></textarea><br>

            <button type="submit" class="button">Add Book</button>
          </form>';
// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $access_number = $_POST['access_number'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $category = $_POST['category'];
    $available = $_POST['available'];
    $details = $_POST['details'];

    // Secure Insert Query (Prepared Statement)
    $stmt = $conn->prepare("INSERT INTO books (access_number, title, author, category, available, details) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssis", $access_number, $title, $author, $category, $available, $details);

    if ($stmt->execute()) {
        echo '<p style="color:green;">Book added successfully!</p>';
        echo '<script>setTimeout(() => { window.location.href = "?page=manage_books"; }, 2000);</script>';
    } else {
        echo '<p style="color:red;">Error adding book.</p>';
    }
    $stmt->close();
}
}

                // Edit Book Page
                if ($page === 'edit_book') {
                    $book_id = $_GET['id'] ?? 0;
                
                    // Secure Query (Prepared Statement)
                    $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
                    $stmt->bind_param("i", $book_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                
                    if ($result->num_rows > 0) {
                        $book = $result->fetch_assoc();
                    } else {
                        echo '<p style="color:red;">Book not found!</p>';
                        return;
                    }
                
                    echo '<h2>Edit Book</h2>';
                    echo '<form method="POST" action="">';
                    echo '<label for="access_number">Access Number:</label><br>';
                    echo '<input type="text" id="access_number" name="access_number" value="' . htmlspecialchars($book['access_number']) . '" required><br>';
                    echo '<label for="title">Title:</label><br>';
                    echo '<input type="text" id="title" name="title" value="' . htmlspecialchars($book['title']) . '" required><br>';
                    echo '<label for="author">Author:</label><br>';
                    echo '<input type="text" id="author" name="author" value="' . htmlspecialchars($book['author']) . '" required><br>';
                    echo '<label for="category">Category:</label><br>';
                    echo '<input type="text" id="category" name="category" value="' . htmlspecialchars($book['category']) . '" required><br>';
                    echo '<label for="available">Available:</label><br>';
                    echo '<select id="available" name="available">
                            <option value="1" ' . ($book['available'] == 1 ? 'selected' : '') . '>Yes</option>
                            <option value="0" ' . ($book['available'] == 0 ? 'selected' : '') . '>No</option>
                          </select><br>';
                    echo '<label for="details">Details:</label><br>';
                    echo '<textarea id="details" name="details">' . htmlspecialchars($book['details']) . '</textarea><br>';
                    echo '<button type="submit" class="button">Update Book</button>';
                    echo '</form>';
                
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        $access_number = $_POST['access_number'];
                        $title = $_POST['title'];
                        $author = $_POST['author'];
                        $category = $_POST['category'];
                        $available = $_POST['available'];
                        $details = $_POST['details'];
                
                        // Secure Update Query (Prepared Statement)
                        $update_stmt = $conn->prepare("UPDATE books SET access_number = ?, title = ?, author = ?, category = ?, available = ?, details = ? WHERE id = ?");
                        $update_stmt->bind_param("ssssisi", $access_number, $title, $author, $category, $available, $details, $book_id);
                
                        if ($update_stmt->execute()) {
                            echo '<p style="color:green;">Book updated successfully!</p>';
                            echo '<script>setTimeout(() => { window.location.href = "?page=manage_books"; }, 2000);</script>';
                        } else {
                            echo '<p style="color:red;">Error updating book.</p>';
                        }
                    }
                }
                
                // Delete Book Page
                if ($page === 'delete_book') {
                    $book_id = $_GET['id'] ?? 0;
                    $delete_query = "DELETE FROM books WHERE id = $book_id";
                    if ($conn->query($delete_query)) {
                        echo '<p style="color:green;">Book deleted successfully!</p>';
                        echo '<script>setTimeout(() => { window.location.href = "?page=manage_books"; }, 2000);</script>';
                    } else {
                        echo '<p style="color:red;">Error deleting book.</p>';
                    }
                }  
                
                // JavaScript to Show Form
                echo '<script>
                        function showBookForm() {
                            document.getElementById("bookForm").style.display = "block";
                        }
                      </script>';
                

      // Search Books Section
if ($page === 'search_books') {
    echo '<h2>Search Books</h2>';
    
    // Search Form
    $search_query = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

    echo '<form method="GET">
            <input type="hidden" name="page" value="search_books">
            <input type="text" name="search" placeholder="Search by title, author, category..." value="' . htmlspecialchars($search_query) . '" required>
            <button type="submit">Search</button>
          </form>';
    
    // SQL Query with Search Filter
    $sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ? OR access_number LIKE ?";
    $stmt = $conn->prepare($sql);
    $search_param = "%$search_query%";
    $stmt->bind_param("ssss", $search_param, $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<table class="table">';
    echo '<tr>
            <th>Access Number</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['access_number']) . '</td>';
            echo '<td>' . htmlspecialchars($row['title']) . '</td>';
            echo '<td>' . htmlspecialchars($row['author']) . '</td>';
            echo '<td>' . htmlspecialchars($row['category']) . '</td>';
            echo '<td>' . ($row['available'] ? 'Yes' : 'No') . '</td>';
            echo '<td>
                    <a href="?page=edit_book&id=' . $row['id'] . '" class="button">Edit</a>
               
                  </td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="6" style="text-align:center; color:red;">No books found.</td></tr>';
    }
    
    echo '</table>';
}


    
    // Manage Users Section
if ($page === 'manage_users') {
    echo '<h2>Manage Users</h2>';
    
    // Add User Button
    echo '<button style="background-color: blue; color: white; padding: 10px 20px; border: none; cursor: pointer; border-radius: 5px; margin-bottom: 15px;" 
    onclick="window.location.href=\'?page=add_user\'">Add User</button>';

    // Search Form
    $search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

    echo '<form method="GET">
            <input type="hidden" name="page" value="manage_users">
            <input type="text" name="search" placeholder="Search by name, email, role..." value="' . htmlspecialchars($search_query, ENT_QUOTES) . '" required>
            <button type="submit">Search</button>
          </form>';

    // SQL Query with Search Filter
    $sql = "SELECT * FROM users WHERE name LIKE ? OR email LIKE ? OR role LIKE ?";
    $stmt = $conn->prepare($sql);
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("sss", $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();

    echo '<table class="table">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Reset Token</th> <!-- ✅ New Column -->
                <th>Actions</th>
            </tr>';

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                    <td>' . htmlspecialchars($row['id']) . '</td>
                    <td>' . htmlspecialchars($row['name']) . '</td>
                    <td>' . htmlspecialchars($row['email']) . '</td>
                    <td>' . htmlspecialchars($row['role']) . '</td>
                    <td>' . ($row['status'] ? 'Active' : 'Inactive') . '</td>
                    <td>' . htmlspecialchars($row['reset_password_token']) . '</td> <!-- ✅ Show token -->
                    <td>
                        <div style="display: flex; gap: 5px;">
                            <a href="?page=edit_user&id=' . $row['id'] . '" class="button" style="flex: 1; text-align: center;">Edit</a>
                            <a href="?page=delete_user&id=' . $row['id'] . '" class="button" style="flex: 1; text-align: center; background-color: red; color: white;" onclick="return confirm(\'Are you sure?\')">Delete</a>
                        </div>
                    </td>
                  </tr>';
        }
    } else {
        echo '<tr><td colspan="7" style="text-align:center; color:red;">No users found.</td></tr>';
    }

    echo '</table>';
    $stmt->close();
}


// Add User Page
if ($page === 'add_user') {
    echo '<h2>Add User</h2>';
    echo '<form method="POST" action="">
            <label for="name">User Name:</label><br>
            <input type="text" id="name" name="name" required><br>

            <label for="email">User Email:</label><br>
            <input type="email" id="email" name="email" required><br>

            <label for="role">Role:</label><br>
            <select id="role" name="role">
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select><br>

            <label for="status">Status:</label><br>
            <select id="status" name="status">
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select><br>

            <button type="submit" class="button">Add User</button>
          </form>';

    // Handle Form Submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $status = $_POST['status'];

        // Secure Insert Query (Prepared Statement)
        $stmt = $conn->prepare("INSERT INTO users (name, email, role, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $name, $email, $role, $status);

        if ($stmt->execute()) {
            echo '<p style="color:green;">User added successfully!</p>';
            echo '<script>setTimeout(() => { window.location.href = "?page=manage_users"; }, 2000);</script>';
        } else {
            echo '<p style="color:red;">Error adding user.</p>';
        }
        $stmt->close();
    }
}
// Edit User Page
if ($page === 'edit_user') {
    $user_id = $_GET['id'] ?? 0;
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo '<p style="color:red;">User not found!</p>';
        return;
    }

    echo '<h2>Edit User</h2>';
    echo '<form method="POST" action="">';
    echo '<label for="name">Name:</label><br>';
    echo '<input type="text" id="name" name="name" value="' . htmlspecialchars($user['name']) . '" required><br>';
    echo '<label for="email">Email:</label><br>';
    echo '<input type="email" id="email" name="email" value="' . htmlspecialchars($user['email']) . '" required><br>';
    echo '<label for="role">Role:</label><br>';
    echo '<input type="text" id="role" name="role" value="' . htmlspecialchars($user['role']) . '" required><br>';
    echo '<label for="status">Status:</label><br>';
    echo '<select id="status" name="status">';
    echo '    <option value="1" ' . ($user['status'] == 1 ? 'selected' : '') . '>Active</option>';
    echo '    <option value="0" ' . ($user['status'] == 0 ? 'selected' : '') . '>Inactive</option>';
    echo '</select><br>';
    echo '<button type="submit" class="button">Update User</button>';
    echo '</form>';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $status = $_POST['status'];

        $update_stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role = ?, status = ? WHERE id = ?");
        $update_stmt->bind_param("sssii", $name, $email, $role, $status, $user_id);

        if ($update_stmt->execute()) {
            echo '<p style="color:green;">User updated successfully!</p>';
            echo '<script>setTimeout(() => { window.location.href = "?page=manage_users"; }, 2000);</script>';
        } else {
            echo '<p style="color:red;">Error updating user.</p>';
        }
    }
}

// Delete User Page
if ($page === 'delete_user') {
    $user_id = $_GET['id'] ?? 0;
    $delete_query = "DELETE FROM users WHERE id = $user_id";
    if ($conn->query($delete_query)) {
        echo '<p style="color:green;">User deleted successfully!</p>';
        echo '<script>setTimeout(() => { window.location.href = "?page=manage_users"; }, 2000);</script>';
    } else {
        echo '<p style="color:red;">Error deleting user.</p>';
    }
} 

// JavaScript to Show Form
echo '<script>
        function showForm() {
            document.getElementById("userForm").style.display = "block";
        }
      </script>';



// Issue Book Section
if ($page === 'issue_book') {
    echo '<h2>Issue Book</h2>';
    
    // Search Form
    $search_query = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

    echo '<form method="GET">
            <input type="hidden" name="page" value="issue_book">
            <input type="text" name="search" placeholder="Search by title, author, category..." value="' . htmlspecialchars($search_query) . '" required>
            <button type="submit">Search</button>
          </form>';
    
    // SQL Query with Search Filter
    $sql = "SELECT * FROM books5 WHERE (title LIKE ? OR author LIKE ? OR category LIKE ? OR access_number LIKE ?)";
    $stmt = $conn->prepare($sql);
    $search_param = "%$search_query%";
    $stmt->bind_param("ssss", $search_param, $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<table class="table">';
    echo '<tr>
            <th>Access Number</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['access_number']) . '</td>';
            echo '<td>' . htmlspecialchars($row['title']) . '</td>';
            echo '<td>' . htmlspecialchars($row['author']) . '</td>';
            echo '<td>' . htmlspecialchars($row['category']) . '</td>';
            echo '<td>' . ($row['available'] ? 'Yes' : 'No') . '</td>';
            echo '<td>';
            if ($row['available']) {
                echo '<a href="?page=issue_book_action&id=' . $row['id'] . '" class="button">Issue</a>';
            }
            echo '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="6" style="text-align:center; color:red;">No books found.</td></tr>';
    }
    
    echo '</table>';
}

// Issue Book Action Section
if ($page === 'issue_book_action' && isset($_GET['id'])) {
    $book_id = $_GET['id'];

    // Fetch book details directly from books5
    $sql = "SELECT * FROM books5 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if ($row['available']) { // Only show form if book is available
            echo "<h3>Issue Book: " . htmlspecialchars($row['title']) . "</h3>";

            echo '<form method="POST">
                    <input type="hidden" name="book_id" value="' . $book_id . '">
                    <label>Member ID:</label>
                    <input type="text" name="member_id" required><br><br>
                    <label>Issue Date:</label>
                    <input type="date" name="issue_date" required><br><br>
                    <label>Return Date:</label>
                    <input type="date" name="return_date" required><br><br>
                    <button type="submit" name="issue_book">OK</button>
                  </form>';
        } else {
            echo "<script>alert('This book is already issued!'); window.location.href='?page=issue_book';</script>";
        }
    } else {
        echo "<script>alert('Book not found!'); window.location.href='?page=issue_book';</script>";
    }
}

// Handle Book Issue (Insert Issue + Update Available=0)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['issue_book'])) {
    $book_id = $_POST['book_id'];
    $member_id = $_POST['member_id'];
    $issue_date = $_POST['issue_date'];
    $return_date = $_POST['return_date'];

    // Check if the book is available
    $check_sql = "SELECT available FROM books5 WHERE id = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $stmt->bind_result($available);
    $stmt->fetch();
    $stmt->close();

    if ($available) {
        // Insert into issued_book2 table
        $insert_sql = "INSERT INTO issued_book2 (book_id, member_id, issue_date, return_date, status) VALUES (?, ?, ?, ?, 'issued')";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("iiss", $book_id, $member_id, $issue_date, $return_date);

        if ($stmt->execute()) {
            // Update available status to 0 (No)
            $update_sql = "UPDATE books5 SET available = 0 WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("i", $book_id);
            $stmt->execute();

            echo "<script>
                    setTimeout(function() {
                        alert('Book Issued Successfully!');
                        window.location.href='?page=issue_book';
                    }, 100);
                  </script>";
        } else {
            echo "<script>alert('Failed to issue book!'); window.location.href='?page=issue_book';</script>";
        }
    } else {
        echo "<script>alert('This book is already issued!'); window.location.href='?page=issue_book';</script>";
    }
}

// Return Book Section
if ($page === 'return_book') {
    echo '<h2>Return Book</h2>';
    
    // Search Form
    $search_query = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

    echo '<form method="GET">
            <input type="hidden" name="page" value="return_book">
            <input type="text" name="search" placeholder="Search by title, author, category..." value="' . htmlspecialchars($search_query) . '" required>
            <button type="submit">Search</button>
          </form>';
    
    // SQL Query with Search Filter (using books5 table)
    $sql = "SELECT * FROM books5 WHERE title LIKE ? OR author LIKE ? OR category LIKE ? OR access_number LIKE ?";
    $stmt = $conn->prepare($sql);
    $search_param = "%$search_query%";
    $stmt->bind_param("ssss", $search_param, $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<table class="table">';
    echo '<tr>
            <th>Access Number</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['access_number']) . '</td>';
            echo '<td>' . htmlspecialchars($row['title']) . '</td>';
            echo '<td>' . htmlspecialchars($row['author']) . '</td>';
            echo '<td>' . htmlspecialchars($row['category']) . '</td>';
            echo '<td>' . ($row['available'] ? 'Yes' : 'No') . '</td>';
            echo '<td>';
            if (!$row['available']) { 
                echo '<a href="?page=return_book_action&id=' . $row['id'] . '" class="button">Return</a>';
            } else {
                echo '<span style="color:gray;"> </span>';
            }
            echo '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="6" style="text-align:center; color:red;">No books found.</td></tr>';
    }
    
    echo '</table>';
}

// Return Book Action Section
if ($page === 'return_book_action' && isset($_GET['id'])) {
    $book_id = $_GET['id'];
    
    // Fetch book details (from books5)
    $sql = "SELECT * FROM books5 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo "<h3>Return Book: " . htmlspecialchars($row['title']) . "</h3>";
        
        echo '<form method="POST">
                <input type="hidden" name="book_id" value="' . $book_id . '">
                <label>Member ID:</label>
                <input type="text" name="member_id" required><br><br>
                <label>Return Date:</label>
                <input type="date" name="return_date" required><br><br>
                <button type="submit" name="return_book">OK</button>
              </form>';
    } else {
        echo "<script>alert('Book not found!'); window.location.href='?page=return_book';</script>";
    }
}

// Handle Book Return
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['return_book'])) {
    $book_id = $_POST['book_id'];
    $member_id = $_POST['member_id'];
    $return_date = $_POST['return_date'];

    // Check if the book is issued
    $check_sql = "SELECT * FROM issued_book2 WHERE book_id = ? AND status = 'issued'";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Insert into returned_books
        $insert_sql = "INSERT INTO returned_books (book_id, member_id, return_date) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("iis", $book_id, $member_id, $return_date);

        if ($stmt->execute()) {
            // Update issued_book2 status
            $update_issue_sql = "UPDATE issued_book2 SET status = 'returned' WHERE book_id = ?";
            $stmt = $conn->prepare($update_issue_sql);
            $stmt->bind_param("i", $book_id);
            $stmt->execute();

            // Mark the book as available in books5
            $update_sql = "UPDATE books5 SET available = 1 WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("i", $book_id);
            $stmt->execute();

            echo "<script>alert('Book Returned Successfully!'); window.location.href='?page=return_book';</script>";
            exit();
        } else {
            echo "<script>alert('Failed to return book!');</script>";
        }
    } else {
        echo "<script>alert('This book is not currently issued.');</script>";
    }
}
               
//Show report section
if ($page === 'show_report') {
    echo '<h2 style="font-size: 24px;">Show Report</h2>';
    echo '<form method="POST" action="">';
    echo '<table border="1" style="font-size: 18px; width: 100%;">';

    // Date Pickers
    echo '<tr>';
    echo '<td style="font-size: 20px;">From Date:</td>';
    echo '<td><input type="date" name="from_date" required style="font-size: 18px; width: 100%;"></td>';
    echo '</tr>';

    echo '<tr>';
    echo '<td style="font-size: 20px;">To Date:</td>';
    echo '<td><input type="date" name="to_date" required style="font-size: 18px; width: 100%;"></td>';
    echo '</tr>';

    // Dropdown Selection
    echo '<tr>';
    echo '<td style="font-size: 20px;">Report Type:</td>';
    echo '<td>';
    echo '<select name="report_type" required style="font-size: 18px; width: 100%;">';
    echo '<option value="not_returned">Show List Book Not Returned</option>';
    echo '<option value="issued">Show List Book Issued</option>';
    echo '<option value="overdue">Show List Book Overdue</option>';
    echo '</select>';
    echo '</td>';
    echo '</tr>';

    // Submit Button
    echo '<tr>';
    echo '<td colspan="2" style="text-align: center;">';
    echo '<button type="submit" class="button" style="font-size: 18px; padding: 8px 12px;">Generate Report</button>';
    echo '</td>';
    echo '</tr>';

    echo '</table>';
    echo '</form>';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $from_date = $_POST['from_date'];
        $to_date = $_POST['to_date'];
        $report_type = $_POST['report_type'];

        $sql = "";

        if ($report_type === "not_returned") {
            $sql = "SELECT ib.*, b.title, b.author, b.category, b.access_number 
                    FROM issued_book2 ib
                    JOIN books5 b ON ib.book_id = b.id
                    WHERE ib.status = 'issued'
                    AND ib.issue_date BETWEEN ? AND ?";
        } elseif ($report_type === "issued") {
            $sql = "SELECT ib.*, b.title, b.author, b.category, b.access_number 
                    FROM issued_book2 ib
                    JOIN books5 b ON ib.book_id = b.id
                    WHERE ib.issue_date BETWEEN ? AND ?";
        } elseif ($report_type === "overdue") {
            $sql = "SELECT ib.*, b.title, b.author, b.category, b.access_number 
                    FROM issued_book2 ib
                    JOIN books5 b ON ib.book_id = b.id
                    WHERE ib.status = 'issued' AND ib.return_date < CURDATE()";
        }

        $stmt = $conn->prepare($sql);

        if ($report_type !== "overdue") {
            $stmt->bind_param("ss", $from_date, $to_date);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        // Display Report
        echo '<h2 style="font-size: 24px;">Report</h2>';
        echo '<table border="1" style="font-size: 18px; width: 100%;">';

        echo '<tr>';
        echo '<th style="font-size: 20px;">Access Number</th>';
        echo '<th style="font-size: 20px;">Title</th>';
        echo '<th style="font-size: 20px;">Author</th>';
        echo '<th style="font-size: 20px;">Category</th>';
        echo '<th style="font-size: 20px;">Member ID</th>';
        echo '<th style="font-size: 20px;">Issue Date</th>';
        echo '<th style="font-size: 20px;">Return Date</th>';
        echo '<th style="font-size: 20px;">Status</th>';
        echo '</tr>';

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['access_number']) . '</td>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['title']) . '</td>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['author']) . '</td>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['category']) . '</td>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['member_id']) . '</td>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['issue_date']) . '</td>';
                echo '<td style="font-size: 18px;">' . ($row['return_date'] ? htmlspecialchars($row['return_date']) : 'Not Returned') . '</td>';
                echo '<td style="font-size: 18px;">' . htmlspecialchars($row['status']) . '</td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="8" style="text-align: center; font-size: 18px;">No Records Found</td></tr>';
        }

        echo '</table>';
    }
}

    
       // Notify User Section
if ($page === 'notify_users') {
    echo '<h2 style="font-size: 24px;">Notify Users</h2>';
    echo '<form method="POST" action="send_notification.php">';
    echo '<table border="1" style="font-size: 18px; width: 100%;">';
    echo '<tr><th style="font-size: 20px;">Email</th><th style="font-size: 20px;">Message</th><th style="font-size: 20px;">Actions</th></tr>';
    echo '<tr>';
    echo '<td><input type="email" id="email" name="email" value="" required style="font-size: 18px; width: 100%;"></td>';
    echo '<td><input type="text" id="message" name="message" value="" required style="font-size: 18px; width: 100%;"></td>';
    echo '<td>';
    echo '<button type="submit" class="button" style="font-size: 18px; padding: 8px 12px;">Send</button>';
    echo '</td>';
    echo '</tr>';
    echo '</table>';
    echo '</form>';
}

    
   
    // Settings Section
if ($page === 'settings') {
    echo "<h2>Settings</h2>";
                    
    echo "<form action='update_settings.php' method='POST' style='max-width: 600px; background: #f8f9fa; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'>
            <div style='margin-bottom: 15px;'>
                <label for='language' style='display: block; font-weight: bold; margin-bottom: 5px;'>Preferred Language</label>
                <select id='language' name='language' style='width: 100%; padding: 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px;'>
                    <option value='english'>English</option>
                    <option value='bangla'>বাংলা</option>
                    <option value='spanish'>Español</option>
                </select>
            </div>

            <div style='margin-bottom: 15px;'>
                <label for='theme' style='display: block; font-weight: bold; margin-bottom: 5px;'>Theme</label>
                <select id='theme' name='theme' style='width: 100%; padding: 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px;'>
                    <option value='light'>Light</option>
                    <option value='dark'>Dark</option>
                </select>
            </div>

            <div style='margin-bottom: 15px;'>
                <label for='notifications' style='display: block; font-weight: bold; margin-bottom: 5px;'>Email Notifications</label>
                <input type='checkbox' id='notifications' name='notifications' value='1' checked> Enable notifications
            </div>

            <button type='submit' style='padding: 10px 20px; font-size: 16px; background-color: #6a5acd; color: white; border: none; border-radius: 5px; cursor: pointer;'>Save Changes</button>
        </form>";

// Process settings form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = $_POST['site_name'];
    $admin_email = $_POST['admin_email'];
    // Logic to save site name and email in the database or configuration
    echo '<p>Settings updated successfully!</p>';
}
}

// Password Section
if ($page === 'password') {
    $adminId = 1;

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $newPassword = $_POST['new_password'] ?? '';

        if (!empty($newPassword)) {
            $hashedPassword = md5($newPassword);
            $updateSql = "UPDATE admin SET Password = ? WHERE id = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("si", $hashedPassword, $adminId);
            if ($updateStmt->execute()) {
                echo "<p style='color:green;'>Password updated successfully.</p>";
            } else {
                echo "<p style='color:red;'>Failed to update password.</p>";
            }
            $updateStmt->close();
        } else {
            echo "<p style='color:red;'>Please enter a password.</p>";
        }
    } 

  
   
    echo "<h2>Current Password: $currentPassword</h2>";

    echo '<form method="POST">';
    echo '<label>old password:<label><br>';
    echo '<input type="text" name="old_password" required><br><br>';

    echo '<form method="POST">';
    echo '<label>New Password:</label><br>';
    echo '<input type="text" name="new_password" required><br><br>';
    

    echo '<label>Confirm Password:</label><br>';
echo '<input type="password" name="confirm_password" required><br><br>';
echo '<button type="submit">Update Password</button>';
    echo '</form>';
}

    ?>
</div>
</body>
</html>


<?php } ?>