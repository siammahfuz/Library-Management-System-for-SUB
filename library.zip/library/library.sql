-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2025 at 04:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Muhammad Masud Tarek', 'tarek@sub.edu.bd', 'admin', '17f94212cbcab37d9b4f6c071275aae9', '2025-04-21 17:27:47');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `access_number` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL DEFAULT 1,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `actions` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`access_number`, `id`, `title`, `author`, `category`, `available`, `details`, `created_at`, `actions`) VALUES
('A001', 23, 'Dipu No. 2', 'Dr. Jafar Iqbal', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A002', 24, 'Pather Panchali', 'Bibhutibhushan Bandopadhyay', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A003', 25, 'Chander Pahar', 'Bibhutibhushan Bandopadhyay', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A004', 26, 'Amar Bondhu Rashed', 'Dr. Jafar Iqbal', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A005', 27, 'Feluda Samagra', 'Satyajit Ray', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A006', 28, 'Shesher Kobita', 'Rabindranath Tagore', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A007', 29, 'Debi', 'Humayun Ahmed', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A008', 30, 'Megher Chaya', 'Humayun Ahmed', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A009', 31, 'The Alchemist', 'Paulo Coelho', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A010', 32, '1984', 'George Orwell', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A011', 33, 'Ami Topu', 'Dr. Jafar Iqbal', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A012', 34, 'Thakurmar Jhuli', 'Dakshinaranjan Mitra Majumder', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A013', 35, 'Tritiyo Matra', 'Muhammed Zafar Iqbal', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A014', 36, 'Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A015', 37, 'Atomic Habits', 'James Clear', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A016', 38, 'Gitanjali', 'Rabindranath Tagore', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A017', 39, 'Nondito Noroke', 'Humayun Ahmed', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A018', 40, 'Rich Dad Poor Dad', 'Robert Kiyosaki', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A019', 41, 'Bela Obela Kalbela', 'Sunil Gangopadhyay', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A020', 42, 'Life of Pi', 'Yann Martel', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A021', 43, 'Digital Fortress', 'Dan Brown', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A022', 44, 'The Power of Now', 'Eckhart Tolle', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A023', 45, 'Lila Majnu', 'Nizami Ganjavi', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A024', 46, 'Brishti Bilash', 'Humayun Ahmed', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A025', 47, 'The Prophet', 'Kahlil Gibran', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A026', 48, 'Rumi\'s Poems', 'Jalaluddin Rumi', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A027', 49, 'Think and Grow Rich', 'Napoleon Hill', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A028', 50, 'Golpo Guccho', 'Rabindranath Tagore', 'General', 1, NULL, '2025-04-23 19:01:11', NULL),
('A029', 51, 'Ekjon Shongeetkarer Chhaya', 'Anisul Hoque', 'General', 0, NULL, '2025-04-23 19:01:11', NULL),
('A030', 52, 'Animal Farm', 'George Orwell', 'General', 1, NULL, '2025-04-23 19:01:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `books5`
--

CREATE TABLE `books5` (
  `id` int(11) NOT NULL,
  `access_number` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `available` tinyint(1) DEFAULT 1,
  `actions` varchar(255) DEFAULT 'Nilanty Nila'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books5`
--

INSERT INTO `books5` (`id`, `access_number`, `title`, `author`, `category`, `available`, `actions`) VALUES
(6, 'A001', 'Dipu No. 2', 'Dr. Jafar Iqbal', 'General', 1, 'Nilanty Nila'),
(7, 'A002', 'Pather Panchali', 'Bibhutibhushan Bandopadhyay', 'General', 0, 'Nilanty Nila'),
(8, 'A003', 'Chander Pahar', 'Bibhutibhushan Bandopadhyay', 'General', 1, 'Nilanty Nila'),
(9, 'A004', 'Amar Bondhu Rashed', 'Dr. Jafar Iqbal', 'General', 0, 'Nilanty Nila'),
(10, 'A005', 'Feluda Samagra', 'Satyajit Ray', 'General', 1, 'Nilanty Nila'),
(11, 'A006', 'Shesher Kobita', 'Rabindranath Tagore', 'General', 0, 'Nilanty Nila'),
(12, 'A007', 'Debi', 'Humayun Ahmed', 'General', 1, 'Nilanty Nila'),
(13, 'A008', 'Megher Chaya', 'Humayun Ahmed', 'General', 0, 'Nilanty Nila'),
(14, 'A009', 'The Alchemist', 'Paulo Coelho', 'General', 1, 'Nilanty Nila'),
(15, 'A010', '1984', 'George Orwell', 'General', 0, 'Nilanty Nila'),
(16, 'A011', 'Ami Topu', 'Dr. Jafar Iqbal', 'General', 1, 'Nilanty Nila'),
(17, 'A012', 'Thakurmar Jhuli', 'Dakshinaranjan Mitra Majumder', 'General', 0, 'Nilanty Nila'),
(18, 'A013', 'Tritiyo Matra', 'Muhammed Zafar Iqbal', 'General', 1, 'Nilanty Nila'),
(19, 'A014', 'Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', 'General', 0, 'Nilanty Nila'),
(20, 'A015', 'Atomic Habits', 'James Clear', 'General', 1, 'Nilanty Nila'),
(21, 'A016', 'Gitanjali', 'Rabindranath Tagore', 'General', 0, 'Nilanty Nila'),
(22, 'A017', 'Nondito Noroke', 'Humayun Ahmed', 'General', 1, 'Nilanty Nila'),
(23, 'A018', 'Rich Dad Poor Dad', 'Robert Kiyosaki', 'General', 0, 'Nilanty Nila'),
(24, 'A019', 'Bela Obela Kalbela', 'Sunil Gangopadhyay', 'General', 1, 'Nilanty Nila'),
(25, 'A020', 'Life of Pi', 'Yann Martel', 'General', 0, 'Nilanty Nila'),
(26, 'A021', 'Digital Fortress', 'Dan Brown', 'General', 1, 'Nilanty Nila'),
(27, 'A022', 'The Power of Now', 'Eckhart Tolle', 'General', 0, 'Nilanty Nila'),
(28, 'A023', 'Lila Majnu', 'Nizami Ganjavi', 'General', 1, 'Nilanty Nila'),
(29, 'A024', 'Brishti Bilash', 'Humayun Ahmed', 'General', 0, 'Nilanty Nila'),
(30, 'A025', 'The Prophet', 'Kahlil Gibran', 'General', 1, 'Nilanty Nila'),
(31, 'A026', 'Rumi\'s Poems', 'Jalaluddin Rumi', 'General', 0, 'Nilanty Nila'),
(32, 'A027', 'Think and Grow Rich', 'Napoleon Hill', 'General', 1, 'Nilanty Nila'),
(33, 'A028', 'Golpo Guccho', 'Rabindranath Tagore', 'General', 0, 'Nilanty Nila'),
(34, 'A029', 'Ekjon Shongeetkarer Chhaya', 'Anisul Hoque', 'General', 1, 'Nilanty Nila'),
(35, 'A030', 'Animal Farm', 'George Orwell', 'General', 0, 'Nilanty Nila');

-- --------------------------------------------------------

--
-- Table structure for table `issued_book2`
--

CREATE TABLE `issued_book2` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `issue_date` date NOT NULL,
  `return_date` date NOT NULL,
  `status` enum('issued','returned') DEFAULT 'issued'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issued_book2`
--

INSERT INTO `issued_book2` (`id`, `book_id`, `member_id`, `issue_date`, `return_date`, `status`) VALUES
(4, 11, 1111, '2025-04-02', '2025-04-17', 'issued'),
(5, 13, 1111, '2025-04-01', '2025-04-16', 'issued'),
(6, 7, 1111, '2025-04-16', '2025-04-24', 'issued'),
(7, 15, 1111, '2025-04-23', '2025-04-23', 'issued'),
(8, 9, 1111, '2025-04-15', '2025-04-25', 'issued'),
(9, 17, 1111, '2025-04-09', '2025-04-24', 'issued'),
(10, 19, 1111, '2025-04-01', '2025-04-25', 'issued'),
(11, 6, 1111, '2025-04-10', '2025-04-25', 'returned'),
(12, 34, 1111, '2025-04-10', '2025-04-25', 'returned'),
(13, 6, 1111, '2025-04-10', '2025-04-25', 'returned'),
(14, 8, 1111, '2025-04-10', '2025-04-25', 'returned'),
(15, 6, 1111, '2025-04-10', '2025-04-25', 'returned'),
(16, 8, 1111, '2024-08-29', '2025-05-03', 'returned'),
(17, 14, 1111, '2025-01-27', '2025-06-19', 'returned'),
(18, 20, 1111, '2025-01-09', '2025-05-29', 'returned');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `member_id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `member_id`, `name`, `email`, `phone`, `created_at`) VALUES
(1, 'M-1001', 'Jahedul Islam Ripon', 'ripon@gmail.com', '1234567890', '2025-03-21 17:42:43'),
(2, 'M-1002', 'Fahim Rahman ', 'fahim@gmail.com', '9876543210', '2025-03-21 17:42:43');

-- --------------------------------------------------------

--
-- Table structure for table `returned_books`
--

CREATE TABLE `returned_books` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `return_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returned_books`
--

INSERT INTO `returned_books` (`id`, `book_id`, `member_id`, `return_date`) VALUES
(2, 6, 1111, '2025-04-25'),
(3, 8, 1111, '2025-04-25'),
(4, 6, 1111, '2025-04-25'),
(5, 8, 1111, '2025-04-09'),
(6, 14, 1111, '2025-03-20'),
(7, 20, 1111, '2025-04-05'),
(8, 34, 1111, '2025-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `searchbook`
--

CREATE TABLE `searchbook` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `access_number` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `booking_date` date NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `searchbook`
--

INSERT INTO `searchbook` (`id`, `name`, `access_number`, `title`, `author`, `category`, `booking_date`, `details`) VALUES
(38, 'Nilanty Nila', 'A001', 'Dipu No. 2', 'Dr. Jafar Iqbal', 'General', '2025-01-01', 'Dipu No. 2 by Dr. Jafar Iqbal'),
(39, 'Nilanty Nila', 'A002', 'Pather Panchali', 'Bibhutibhushan Bandopadhyay', 'General', '2024-12-10', 'Pather Panchali by Bibhutibhushan Bandopadhyay'),
(40, 'Nilanty Nila', 'A003', 'Chander Pahar', 'Bibhutibhushan Bandopadhyay', 'General', '2024-11-20', 'Chander Pahar by Bibhutibhushan Bandopadhyay'),
(41, 'Nilanty Nila', 'A004', 'Amar Bondhu Rashed', 'Dr. Jafar Iqbal', 'General', '2025-02-10', 'Amar Bondhu Rashed by Dr. Jafar Iqbal'),
(42, 'Nilanty Nila', 'A005', 'Feluda Samagra', 'Satyajit Ray', 'General', '2024-10-01', 'Feluda Samagra by Satyajit Ray'),
(43, 'Nilanty Nila', 'A006', 'Shesher Kobita', 'Rabindranath Tagore', 'General', '2025-01-20', 'Shesher Kobita by Rabindranath Tagore'),
(44, 'Nilanty Nila', 'A007', 'Debi', 'Humayun Ahmed', 'General', '2025-03-01', 'Debi by Humayun Ahmed'),
(45, 'Nilanty Nila', 'A008', 'Megher Chaya', 'Humayun Ahmed', 'General', '2025-03-20', 'Megher Chaya by Humayun Ahmed'),
(46, 'Nilanty Nila', 'A009', 'The Alchemist', 'Paulo Coelho', 'General', '2025-02-15', 'The Alchemist by Paulo Coelho'),
(47, 'Nilanty Nila', 'A010', '1984', 'George Orwell', 'General', '2024-09-01', '1984 by George Orwell'),
(48, 'Nilanty Nila', 'A011', 'Ami Topu', 'Dr. Jafar Iqbal', 'General', '2025-04-01', 'Ami Topu by Dr. Jafar Iqbal'),
(49, 'Nilanty Nila', 'A012', 'Thakurmar Jhuli', 'Dakshinaranjan Mitra Majumder', 'General', '2024-08-15', 'Thakurmar Jhuli by Dakshinaranjan Mitra Majumder'),
(50, 'Nilanty Nila', 'A013', 'Tritiyo Matra', 'Muhammed Zafar Iqbal', 'General', '2025-04-10', 'Tritiyo Matra by Muhammed Zafar Iqbal'),
(51, 'Nilanty Nila', 'A014', 'Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', 'General', '2025-01-10', 'Harry Potter and the Sorcerer\'s Stone by J.K. Rowling'),
(52, 'Nilanty Nila', 'A015', 'Atomic Habits', 'James Clear', 'General', '2025-02-05', 'Atomic Habits by James Clear'),
(53, 'Nilanty Nila', 'A016', 'Gitanjali', 'Rabindranath Tagore', 'General', '2025-01-01', 'Gitanjali by Rabindranath Tagore'),
(54, 'Nilanty Nila', 'A017', 'Nondito Noroke', 'Humayun Ahmed', 'General', '2024-12-01', 'Nondito Noroke by Humayun Ahmed'),
(55, 'Nilanty Nila', 'A018', 'Rich Dad Poor Dad', 'Robert Kiyosaki', 'General', '2025-03-05', 'Rich Dad Poor Dad by Robert Kiyosaki'),
(56, 'Nilanty Nila', 'A019', 'Bela Obela Kalbela', 'Sunil Gangopadhyay', 'General', '2024-11-01', 'Bela Obela Kalbela by Sunil Gangopadhyay'),
(57, 'Nilanty Nila', 'A020', 'Life of Pi', 'Yann Martel', 'General', '2025-02-01', 'Life of Pi by Yann Martel'),
(58, 'Nilanty Nila', 'A021', 'Digital Fortress', 'Dan Brown', 'General', '2025-03-25', 'Digital Fortress by Dan Brown'),
(59, 'Nilanty Nila', 'A022', 'The Power of Now', 'Eckhart Tolle', 'General', '2025-01-15', 'The Power of Now by Eckhart Tolle'),
(60, 'Nilanty Nila', 'A023', 'Lila Majnu', 'Nizami Ganjavi', 'General', '2025-04-05', 'Lila Majnu by Nizami Ganjavi'),
(61, 'Nilanty Nila', 'A024', 'Brishti Bilash', 'Humayun Ahmed', 'General', '2024-10-10', 'Brishti Bilash by Humayun Ahmed'),
(62, 'Nilanty Nila', 'A025', 'The Prophet', 'Kahlil Gibran', 'General', '2025-01-05', 'The Prophet by Kahlil Gibran'),
(63, 'Nilanty Nila', 'A026', 'Rumi\'s Poems', 'Jalaluddin Rumi', 'General', '2025-02-10', 'Rumi\'s Poems by Jalaluddin Rumi'),
(64, 'Nilanty Nila', 'A027', 'Think and Grow Rich', 'Napoleon Hill', 'General', '2025-01-12', 'Think and Grow Rich by Napoleon Hill'),
(65, 'Nilanty Nila', 'A028', 'Golpo Guccho', 'Rabindranath Tagore', 'General', '2024-11-05', 'Golpo Guccho by Rabindranath Tagore'),
(66, 'Nilanty Nila', 'A029', 'Ekjon Shongeetkarer Chhaya', 'Anisul Hoque', 'General', '2025-02-25', 'Ekjon Shongeetkarer Chhaya by Anisul Hoque'),
(67, 'Nilanty Nila', 'A030', 'Animal Farm', 'George Orwell', 'General', '2024-09-15', 'Animal Farm by George Orwell');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL,
  `StudentId` varchar(100) DEFAULT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`id`, `StudentId`, `FullName`, `EmailId`, `MobileNumber`, `Password`, `Status`, `RegDate`, `UpdationDate`) VALUES
(12, 'UG02-51-19-003', 'Nilanty Nila', 'nilanty@gmail.com', '0130000000', '25d55ad283aa400af464c76d713c07ad', 1, '2025-02-15 20:06:42', NULL),
(15, 'UG02-51-19-006', 'Jahedul Islam Ripon', 'jahedul@gmail.com', '1301155632', '5e8667a439c68f5145dd2fcbecf02209', 1, '2025-03-01 11:02:13', NULL),
(18, 'UG02-51-19-007', 'Jahedul islam Ripon', 'ripon@gmail.com', '0130000000', 'b7a2c3b25c9441b0a38d0a874ace268b', 1, '2025-04-10 05:38:33', '2025-05-01 18:28:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `role`, `status`, `reset_password_token`, `created_at`, `reset_token`) VALUES
(1, 'Nilanty Nila', 'nilanty@gmail.com', 'Member', 1, 'nilanty@gmail.com', '2025-02-23 18:01:50', NULL),
(2, 'Jahedul Islam', 'jahedul050222@gmail.com', 'Member', 1, 'jahedul050222@gmail.com', '2025-02-23 18:01:50', NULL),
(3, 'Fahim Faysal', 'fahim@gmail.com', 'Member', 1, 'fahim@gmail.com', '2025-03-10 14:47:47', NULL),
(4, 'Shovon Hossain', 'shovon@gmail.com', 'Member', 1, 'shovon@gmail.com', '2025-04-27 20:05:33', NULL),
(5, 'Sazon Mia', 'sazon@gmail.com', 'Member', 1, 'sazon@gmail.com', '2025-04-27 20:05:33', NULL),
(6, 'Rifat Karim', 'rifat@gmail.com', 'Member', 1, 'rifat@gmail.com', '2025-04-27 20:05:33', NULL),
(7, 'Naimur Rahman', 'naimur@gmail.com', 'Member', 1, 'naimur@gmail.com', '2025-04-27 20:05:33', NULL),
(8, 'Tonmoy Alam', 'tonmoy@gmail.com', 'Member', 1, 'tonmoy@gmail.com', '2025-04-27 20:05:33', NULL),
(9, 'Sadia Sultana', 'sadia@gmail.com', 'Member', 1, 'sadia@gmail.com', '2025-04-27 20:05:33', NULL),
(10, 'Tamim Iqbal', 'tamim@gmail.com', 'Member', 1, 'tamim@gmail.com', '2025-04-27 20:05:33', NULL),
(11, 'Sumaiya Haque', 'sumaiya@gmail.com', 'Member', 1, 'sumaiya@gmail.com', '2025-04-27 20:05:33', NULL),
(12, 'Sabbir Rahman', 'sabbir@gmail.com', 'Member', 1, 'sabbir@gmail.com', '2025-04-27 20:05:33', NULL),
(13, 'Nusrat Jahan', 'nusrat@gmail.com', 'Member', 1, 'nusrat@gmail.com', '2025-04-27 20:05:33', NULL),
(14, 'Rakib Hossain', 'rakib@gmail.com', 'Member', 1, 'rakib@gmail.com', '2025-04-27 20:05:33', NULL),
(15, 'Taslima Akter', 'taslima@gmail.com', 'Member', 1, 'taslima@gmail.com', '2025-04-27 20:05:33', NULL),
(16, 'Fahim Ahmed', 'fahimahmed@gmail.com', 'Member', 1, 'fahimahmed@gmail.com', '2025-04-27 20:05:33', NULL),
(17, 'Farzana Yasmin', 'farzana@gmail.com', 'Member', 1, 'farzana@gmail.com', '2025-04-27 20:05:33', NULL),
(18, 'Maruf Hasan', 'maruf@gmail.com', 'Member', 1, 'maruf@gmail.com', '2025-04-27 20:05:33', NULL),
(19, 'Labiba Chowdhury', 'labiba@gmail.com', 'Member', 1, 'labiba@gmail.com', '2025-04-27 20:05:33', NULL),
(20, 'Zahidul Islam', 'zahidul@gmail.com', 'Member', 1, 'zahidul@gmail.com', '2025-04-27 20:05:33', NULL),
(21, 'Orpa Sultana', 'orpa@gmail.com', 'Member', 1, 'orpa@gmail.com', '2025-04-27 20:05:33', NULL),
(22, 'Jubayer Hossain', 'jubayer@gmail.com', 'Member', 1, 'jubayer@gmail.com', '2025-04-27 20:05:33', NULL),
(23, 'Munia Khatun', 'muniakhatun@gmail.com', 'Member', 1, 'muniakhatun@gmail.com', '2025-04-27 20:05:33', NULL),
(24, 'Shohanur Rahman', 'shohanur@gmail.com', 'Member', 1, 'shohanur@gmail.com', '2025-04-27 20:05:33', NULL),
(25, 'Mim Akter', 'mim@gmail.com', 'Member', 1, 'mim@gmail.com', '2025-04-27 20:05:33', NULL),
(26, 'Sakib Rahman', 'sakib@gmail.com', 'Member', 1, 'sakib@gmail.com', '2025-04-27 20:05:33', NULL),
(27, 'Sharmin Sultana', 'sharmin@gmail.com', 'Member', 1, 'sharmin@gmail.com', '2025-04-27 20:05:33', NULL),
(28, 'Hasibul Hasan', 'hasibul@gmail.com', 'Member', 1, 'hasibul@gmail.com', '2025-04-27 20:05:33', NULL),
(29, 'Papia Akter', 'papia@gmail.com', 'Member', 1, 'papia@gmail.com', '2025-04-27 20:05:33', NULL),
(30, 'Nahiyan Islam', 'nahiyan@gmail.com', 'Member', 1, 'nahiyan@gmail.com', '2025-04-27 20:05:33', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `access_number` (`access_number`);

--
-- Indexes for table `books5`
--
ALTER TABLE `books5`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `access_number` (`access_number`);

--
-- Indexes for table `issued_book2`
--
ALTER TABLE `issued_book2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `member_id` (`member_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `returned_books`
--
ALTER TABLE `returned_books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `searchbook`
--
ALTER TABLE `searchbook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `StudentId` (`StudentId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `books5`
--
ALTER TABLE `books5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `issued_book2`
--
ALTER TABLE `issued_book2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `returned_books`
--
ALTER TABLE `returned_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `searchbook`
--
ALTER TABLE `searchbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `issued_book2`
--
ALTER TABLE `issued_book2`
  ADD CONSTRAINT `issued_book2_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books5` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `returned_books`
--
ALTER TABLE `returned_books`
  ADD CONSTRAINT `returned_books_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books5` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
