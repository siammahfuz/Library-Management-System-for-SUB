<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "library"; // Database name

// MySQL Database Connection
$conn = new mysqli('localhost', 'root', '', 'library');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Search Query
$search_query = "";
if (isset($_GET['search'])) {
    $search_query = $conn->real_escape_string($_GET['search']);
    $sql = "SELECT * FROM searchbook WHERE name LIKE '%$search_query%' OR author LIKE '%$search_query%' OR title LIKE '%$search_query%' OR category LIKE '%$search_query%'";
} else {
    $sql = "SELECT * FROM searchbook";
}

$result = $conn->query($sql);

// Dummy user data (Replace with database query)
$userProfile = [
    'name' => '',
    'id' => '',
    'email' => ''
];

// Get the page parameter (default: profile)
$page = isset($_GET['page']) ? $_GET['page'] : 'profile';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 250px;
            background-color: #1a1a1a;
            color: white;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        .sidebar a {
            color: #b3b3b3;
            text-decoration: none;
            margin: 10px 0;
            font-size: 16px;
            display: block;
            padding: 5px;
        }
        .sidebar a:hover, .sidebar a.active {
            color: white;
            font-weight: bold;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
            background-color: white;
            border-radius: 12px;
            margin: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background-color: #6a5acd;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #5a4ebc;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>          
<body>
<div class="sidebar"> 
    <a href="http://localhost/library/my-profile.php" ? class="<?= $page == '' ? 'active' : '' ?>">My Profile</a>
    <a href="?page=search" class="<?= $page == 'search' ? 'active' : '' ?>">Search Book</a>
    <a href="?page=history" class="<?= $page == 'history' ? 'active' : '' ?>">My History</a>
    <a href="http://localhost/library/password-change.php" class="<?= $page == '' ? 'active' : '' ?>">Password</a>
    <a href="?page=settings" class="<?= $page == 'settings' ? 'active' : '' ?>">Settings</a>
    <a href="logout.php">Logout</a>
</div>  
    <div class="content">
        <?php
        switch ($page) {
            case 'profile':
               
                break;
            
            
            

            case 'search':
                $search_query = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

echo "<h2>Search Book</h2>";
echo "<form method='GET'>
        <input type='hidden' name='page' value='search'>
        <input type='text' name='search' placeholder='Search by book...' value='$search_query' required>
        <button type='submit'>Search</button>
      </form>";

// SQL query to search books
$sql = "SELECT * FROM books 
        WHERE name LIKE '%$search_query%' 
        OR access_number LIKE '%$search_query%' 
        OR title LIKE '%$search_query%' 
        OR author LIKE '%$search_query%' 
        OR category LIKE '%$search_query%'";



if ($result->num_rows > 0) {
    echo "<table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Access Number</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Booking Date</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['name']}</td>
                <td>{$row['access_number']}</td>
                <td>{$row['title']}</td>
                <td>{$row['author']}</td>
                <td>{$row['category']}</td>
                <td>{$row['booking_date']}</td>
                <td>{$row['details']}</td>
              </tr>";
    }

    echo "</tbody></table>";
} else {
    echo "<p>No books found.</p>";
}
                break;

                case 'search':
                    echo "<h2>Search for a Book</h2>";
                    echo "<form method='POST'>";
                    echo "<input type='text' name='query' placeholder='Enter book title or author' required>";
                    echo "<button type='submit'>Search</button>";
                    echo "</form>";
                    
                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        $query = $_POST['query'];
                        echo "<p>Searching for: <strong>$query</strong></p>";
                        // Database query logic goes here
                    }
                    break;
                
                
                
                    case 'password':
                        if ($page === 'password') {
                            $adminId = 1;
                            
                            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                $oldPassword = $_POST['old-password'] ?? '';
                                $newPassword = $_POST['new-password'] ?? '';
                                $confirmPassword = $_POST['confirm-password'] ?? '';
                    
                                if (empty($oldPassword) || empty($newPassword) || empty($confirmPassword)) {
                                    echo "<p style='color:red;'>All fields are required.</p>";
                                } elseif ($newPassword !== $confirmPassword) {
                                    echo "<p style='color:red;'>New password and confirm password do not match.</p>";
                                } else {
                                    $sql = "SELECT Password FROM tblstudents WHERE id = ?";
                                    $stmt = $conn->prepare($sql);
                                    if ($stmt) {
                                        $stmt->bind_param("i", $adminId);
                                        $stmt->execute();
                                        $stmt->bind_result($currentPassword);
                                        if ($stmt->fetch()) {
                                            if (md5($oldPassword) !== $currentPassword) {
                                                echo "<p style='color:red;'>Old password is incorrect.</p>";
                                            } else {
                                                $stmt->close();
                                                $hashedPassword = md5($newPassword);
                                                
                                                $updateSql = "UPDATE tblstudents SET Password = ? WHERE id = ?";
                                                $updateStmt = $conn->prepare($updateSql);
                                                if ($updateStmt) {
                                                    $updateStmt->bind_param("si", $hashedPassword, $adminId);
                                                    if ($updateStmt->execute()) {
                                                        echo "<p style='color:green;'>Password updated successfully.</p>";
                                                    } else {
                                                        echo "<p style='color:red;'>Failed to update password.</p>";
                                                    }
                                                    $updateStmt->close();
                                                } else {
                                                    echo "<p style='color:red;'>Failed to prepare update query.</p>";
                                                }
                                            }
                                        } else {
                                            echo "<p style='color:red;'>User not found.</p>";
                                        }
                                        $stmt->close();
                                    } else {
                                        echo "<p style='color:red;'>Failed to prepare select query.</p>";
                                    }
                                }
                            }
                            echo "<h2>Change Password</h2>";
                            echo "<form method='POST'>
                                <div class='form-group'>
                                    <label for='old-password'>Old Password</label>
                                    <input type='password' id='old-password' name='old-password' required>
                                </div>
                                <div class='form-group'>
                                    <label for='new-password'>New Password</label>
                                    <input type='password' id='new-password' name='new-password' required>
                                </div>
                                <div class='form-group'>
                                    <label for='confirm-password'>Confirm New Password</label>
                                    <input type='password' id='confirm-password' name='confirm-password' required>
                                </div>
                                <button type='submit'>Save</button>
                            </form>";
                        }
                        break;
                      
                    
                

                case 'history':
                    echo "<h2>My History</h2>";

                    // Sample history data (Replace this with a database query)
                    $history = [
                        [
                            'title' => 'Dipu No. 2',
                            'author' => 'Dr. Jafar Iqbal',
                            'access_number' => 'A001',
                            'issue_date' => '2025-01-01',
                            'return_date' => '2025-01-15',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Pather Panchali',
                            'author' => 'Bibhutibhushan Bandopadhyay',
                            'access_number' => 'A002',
                            'issue_date' => '2024-12-10',
                            'return_date' => '2024-12-25',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Chander Pahar',
                            'author' => 'Bibhutibhushan Bandopadhyay',
                            'access_number' => 'A003',
                            'issue_date' => '2024-11-20',
                            'return_date' => '2024-12-05',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Amar Bondhu Rashed',
                            'author' => 'Dr. Jafar Iqbal',
                            'access_number' => 'A004',
                            'issue_date' => '2025-02-10',
                            'return_date' => '2025-02-25',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Feluda Samagra',
                            'author' => 'Satyajit Ray',
                            'access_number' => 'A005',
                            'issue_date' => '2024-10-01',
                            'return_date' => '2024-10-15',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Shesher Kobita',
                            'author' => 'Rabindranath Tagore',
                            'access_number' => 'A006',
                            'issue_date' => '2025-01-20',
                            'return_date' => '2025-02-04',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Debi',
                            'author' => 'Humayun Ahmed',
                            'access_number' => 'A007',
                            'issue_date' => '2025-03-01',
                            'return_date' => '2025-03-15',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Megher Chaya',
                            'author' => 'Humayun Ahmed',
                            'access_number' => 'A008',
                            'issue_date' => '2025-03-20',
                            'return_date' => '2025-04-04',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'The Alchemist',
                            'author' => 'Paulo Coelho',
                            'access_number' => 'A009',
                            'issue_date' => '2025-02-15',
                            'return_date' => '2025-03-01',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => '1984',
                            'author' => 'George Orwell',
                            'access_number' => 'A010',
                            'issue_date' => '2024-09-01',
                            'return_date' => '2024-09-15',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Ami Topu',
                            'author' => 'Dr. Jafar Iqbal',
                            'access_number' => 'A011',
                            'issue_date' => '2025-04-01',
                            'return_date' => '2025-04-16',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Thakurmar Jhuli',
                            'author' => 'Dakshinaranjan Mitra Majumder',
                            'access_number' => 'A012',
                            'issue_date' => '2024-08-15',
                            'return_date' => '2024-08-30',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Tritiyo Matra',
                            'author' => 'Muhammed Zafar Iqbal',
                            'access_number' => 'A013',
                            'issue_date' => '2025-04-10',
                            'return_date' => '2025-04-25',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Harry Potter and the Sorcerer\'s Stone',
                            'author' => 'J.K. Rowling',
                            'access_number' => 'A014',
                            'issue_date' => '2025-01-10',
                            'return_date' => '2025-01-24',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Atomic Habits',
                            'author' => 'James Clear',
                            'access_number' => 'A015',
                            'issue_date' => '2025-02-05',
                            'return_date' => '2025-02-20',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Gitanjali',
                            'author' => 'Rabindranath Tagore',
                            'access_number' => 'A016',
                            'issue_date' => '2025-01-01',
                            'return_date' => '2025-01-15',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Nondito Noroke',
                            'author' => 'Humayun Ahmed',
                            'access_number' => 'A017',
                            'issue_date' => '2024-12-01',
                            'return_date' => '2024-12-15',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Rich Dad Poor Dad',
                            'author' => 'Robert Kiyosaki',
                            'access_number' => 'A018',
                            'issue_date' => '2025-03-05',
                            'return_date' => '2025-03-19',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Bela Obela Kalbela',
                            'author' => 'Sunil Gangopadhyay',
                            'access_number' => 'A019',
                            'issue_date' => '2024-11-01',
                            'return_date' => '2024-11-16',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Life of Pi',
                            'author' => 'Yann Martel',
                            'access_number' => 'A020',
                            'issue_date' => '2025-02-01',
                            'return_date' => '2025-02-15',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Digital Fortress',
                            'author' => 'Dan Brown',
                            'access_number' => 'A021',
                            'issue_date' => '2025-03-25',
                            'return_date' => '2025-04-10',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'The Power of Now',
                            'author' => 'Eckhart Tolle',
                            'access_number' => 'A022',
                            'issue_date' => '2025-01-15',
                            'return_date' => '2025-01-30',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Lila Majnu',
                            'author' => 'Nizami Ganjavi',
                            'access_number' => 'A023',
                            'issue_date' => '2025-04-05',
                            'return_date' => '2025-04-20',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Brishti Bilash',
                            'author' => 'Humayun Ahmed',
                            'access_number' => 'A024',
                            'issue_date' => '2024-10-10',
                            'return_date' => '2024-10-25',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'The Prophet',
                            'author' => 'Kahlil Gibran',
                            'access_number' => 'A025',
                            'issue_date' => '2025-01-05',
                            'return_date' => '2025-01-20',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Rumi\'s Poems',
                            'author' => 'Jalaluddin Rumi',
                            'access_number' => 'A026',
                            'issue_date' => '2025-02-10',
                            'return_date' => '2025-02-25',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Think and Grow Rich',
                            'author' => 'Napoleon Hill',
                            'access_number' => 'A027',
                            'issue_date' => '2025-01-12',
                            'return_date' => '2025-01-26',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Golpo Guccho',
                            'author' => 'Rabindranath Tagore',
                            'access_number' => 'A028',
                            'issue_date' => '2024-11-05',
                            'return_date' => '2024-11-20',
                            'status' => 'Overdue'
                        ],
                        [
                            'title' => 'Ekjon Shongeetkarer Chhaya',
                            'author' => 'Anisul Hoque',
                            'access_number' => 'A029',
                            'issue_date' => '2025-02-25',
                            'return_date' => '2025-03-10',
                            'status' => 'Returned'
                        ],
                        [
                            'title' => 'Animal Farm',
                            'author' => 'George Orwell',
                            'access_number' => 'A030',
                            'issue_date' => '2024-09-15',
                            'return_date' => '2024-09-30',
                            'status' => 'Overdue'
                        ],
                    ];
                    
                    
                
                    if (!empty($history)) {
                        echo "<table style='width: 100%; border-collapse: collapse; margin-top: 20px;'>
                                <thead>
                                    <tr style='background-color: #f2f2f2;'>
                                        <th style='padding: 10px; border: 1px solid #ddd; text-align: left;'>Title</th>
                                        <th style='padding: 10px; border: 1px solid #ddd; text-align: left;'>Author</th>
                                        <th style='padding: 10px; border: 1px solid #ddd; text-align: left;'>Access Number</th>
                                        <th style='padding: 10px; border: 1px solid #ddd; text-align: left;'>Issue Date</th>
                                        <th style='padding: 10px; border: 1px solid #ddd; text-align: left;'>Return Date</th>
                                        <th style='padding: 10px; border: 1px solid #ddd; text-align: left;'>Status</th>
                                    </tr>
                                </thead>
                                <tbody>";
                        
                        foreach ($history as $entry) {
                            echo "<tr>
                                    <td style='padding: 10px; border: 1px solid #ddd;'>{$entry['title']}</td>
                                    <td style='padding: 10px; border: 1px solid #ddd;'>{$entry['author']}</td>
                                    <td style='padding: 10px; border: 1px solid #ddd;'>{$entry['access_number']}</td>
                                    <td style='padding: 10px; border: 1px solid #ddd;'>{$entry['issue_date']}</td>
                                    <td style='padding: 10px; border: 1px solid #ddd;'>{$entry['return_date']}</td>
                                    <td style='padding: 10px; border: 1px solid #ddd; font-weight: bold; color: " . ($entry['status'] == 'Overdue' ? 'red' : 'green') . ";'>{$entry['status']}</td>
                                  </tr>";
                        }
                
                        echo "</tbody></table>";
                    } else {
                        echo "<p style='color: gray;'>No books currently issued.</p>";
                    }
                    break;
                
                

                    case 'settings':
                        echo "<h2>Settings</h2>";
                    
                        echo "<form action='update_settings.php' method='POST' style='max-width: 600px; background: #f8f9fa; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'>
                                <div style='margin-bottom: 15px;'>
                                    <label for='language' style='display: block; font-weight: bold; margin-bottom: 5px;'>Preferred Language</label>
                                    <select id='language' name='language' style='width: 100%; padding: 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px;'>
                                        <option value='english'>English</option>
                                        <option value='bangla'>বাংলা</option>
                                        <option value='spanish'>Español</option>
                                    </select>
                                </div>
                    
                                <div style='margin-bottom: 15px;'>
                                    <label for='theme' style='display: block; font-weight: bold; margin-bottom: 5px;'>Theme</label>
                                    <select id='theme' name='theme' style='width: 100%; padding: 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px;'>
                                        <option value='light'>Light</option>
                                        <option value='dark'>Dark</option>
                                    </select>
                                </div>
                    
                                <div style='margin-bottom: 15px;'>
                                    <label for='notifications' style='display: block; font-weight: bold; margin-bottom: 5px;'>Email Notifications</label>
                                    <input type='checkbox' id='notifications' name='notifications' value='1' checked> Enable notifications
                                </div>
                    
                                <button type='submit' style='padding: 10px 20px; font-size: 16px; background-color: #6a5acd; color: white; border: none; border-radius: 5px; cursor: pointer;'>Save Changes</button>
                            </form>";
                    
                        break;

            case 'logout':
                session_destroy();
                header("Location: login.php");
                exit;
                break;

            
        }
        ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
